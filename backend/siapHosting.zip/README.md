beberapa hal yang harus dilakuin
1. Login Register Logout (database + model) tolong benerin kayaknya jelek desain databasenya. ak masih ga yakin jwt ditaruk database
2. login register tolong passwordnya di encryption. 
3. tolong bikin middleware implementasino buat jwt authentication sama authorizationnya.
4. authentication itu buat dia token nya sesuai ga (yang mainan token di header)
5. authorization itu buat ngecek role nya (diimplementasino di seller) biar pass di seller itu kalau mau ngapa"in dia harus sebagai seller rolenya
6. cek no model e lek kurang sesuai tolong gantino sekalian database nya juga di ganti kalau gitu. gpp ganti database pokoknya benar dulu biar enak pass di fetch di front end nya.